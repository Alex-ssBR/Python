# desafio 3 ____________________________________
nome = str(input('Digite seu nome:\n'))
nomeinvertido = ''.join(reversed(nome))
print(nomeinvertido)
